import jwt from "jsonwebtoken";
const jwtAuth = (req, res, next) => {
    try {
        const token = req.header("token")
        if (!token) return res.status(400).json({ msg: "Invalid Authentication" })

        jwt.verify(token, process.env.JWT_SECRET_KEY, (err, user) => {
            if (err) return res.status(400).json({ msg: "Authorization is not valid." })
            req.user = user;
            next()
        })
    } catch (err) {
        return res.status(500).json({ msg: err.msg })

    } 

};
export default jwtAuth;
