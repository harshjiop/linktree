import mongoose, { Schema, model } from "mongoose";
// import User from "./user.models.js";


const linkSchema = new Schema(
  {
    title: {
      type: "string",
      required: true,
      // unique: true,
    },
    link: {
      type: "string",
      required: true,
    },
    author: {
      // type: mongoose.Types.ObjectId,
      // type: mongoose.SchemaTypes.ObjectId,
      // ref: "Userdata",
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Users'
      // ,
      // required: true,
    },
  },
  {
    timestamps: true,
  }
);
// linkSchema.path("User").ref("Userdata");

// console.log(linkSchema.paths.user);

const link = model("link", linkSchema);
export default link;
