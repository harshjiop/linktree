import linkSchema from "../models/link.models.js";

const home = async (req, res) => {
  res.json({ Type: " link get" });
};
const createlink = async (req, res) => {
  try {
    const { title, link,  } = req.body;
    const mylink = linkSchema.create({
      title,
      link,
      author_id: req.user.id,
    });
    res.status(200).json({
      success: true,
      message: "link add ",
      data: mylink,
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message,
    });
  }
};
export { home, createlink };
