import User from "../models/user.models.js";

const cookieOptions = {
  maxAge: 7 * 24 * 60 * 60 * 1000,
  httpOnly: true,
  secure: true,
};

const home = async (req, res) => {
  res.json({ Type: "get" });
};
const register = async (req, res) => {
  try {
    const { FullName, email, password } = req.body;

    if (!FullName || !email || !password) {
      return res.status(400).json({ msg: "Please enter all fields" });
    }

    const UserExists = await User.findOne({ email });
    if (UserExists) {
      return res
        .status(400)
        .json({ msg: "This email Already Exists pls login" });
    }

    const user = await User.create({
      FullName,
      email,
      password,
    });
   

    user.save();
    const token = await User.ganarateJWTToken();
    console.log("jwttoken", token);
   
    res.cookie("token", token, cookieOptions);

    if (!user) {
      res.status(400).json({ msg: "Some Thing went Wrong! plse try again" });
    }

    res.status(201).json({
      success: true,
      message: "User created Successfully",
      user,
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: "some thing went wrong",
    });
  }
};
const login = async (req, res) => {};
const logout = async (req, res) => {};

const myprofile = async (req, res) => {
  try {
    const userId = req.user.id;
    const user = await User.findById(userId);
    res.status(201).json({
      success: true,
      message: "User created Successfully",
      user,
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: "user deteles not found",
    });
  }
};

export { home, register, login, logout, myprofile };
