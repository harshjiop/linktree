import express from "express";
import {
  home,
  register,
  login,
  logout,
  myprofile,
} from "../Controlles/user.controlles.js";

const router = express.Router();
router.get("/", home);
router.post("/register", register);
router.post("/login", login);
router.get("/logout", logout);
router.get("/myprofile", myprofile);

export default router;
