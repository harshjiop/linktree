import express from "express";
import { createlink, home } from "../Controlles/link.controlles.js";

const router = express.Router();
router.route("/").get(home);
router.route("/addlink").post(createlink);


export default router;
