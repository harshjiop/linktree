import mongoose, { Schema, model } from "mongoose";
import user from "./user.models.js";

const linkSchema = new Schema(
  {
    title: {
      type: "string",
      required: true,
      unique: true,
    },
    link: {
      type: "string",
      required: true,
    },
    author: {
      type: mongoose.Types.ObjectId,
      ref: "user",
      required: true,
    },
  },
  {
    timestamps: true,
  }
);

const link = model("link", linkSchema);
export default link;
